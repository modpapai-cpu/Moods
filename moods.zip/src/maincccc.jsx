import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Volume2, Heart, Search, Music2, Headphones, ListMusic, Home, Library, ChevronDown, Menu, X, UserRound, UsersRound, Copy, Plus, Trash2, ExternalLink } from 'lucide-react';
import { GoogleAuthProvider, onAuthStateChanged, signInWithCredential, signOut } from 'firebase/auth';
import { onValue, push, ref, remove, serverTimestamp, set, update } from 'firebase/database';
import { auth, database, databaseConfigured, firebaseConfigured, googleClientId, youtubeApiKey } from './firebase';
import './style.css';

const playlists = [
 {id:'late-night',name:'Late Night Feelings',mood:'ALONE',desc:'For the quiet hours and loud thoughts.',color:'plum',icon:'☾',songs:[
  {title:'Midnight City Lights',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',duration:'6:12'},
  {title:'Slow Motion',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',duration:'7:02'},
  {title:'After the Rain',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',duration:'5:03'}]},
 {id:'soft-love',name:'Soft Love',mood:'LOVE',desc:'A little warmth, a little romance.',color:'rose',icon:'♡',songs:[
  {title:'Closer to You',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',duration:'5:ಂತ'},
  {title:'Golden Hour',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',duration:'5:32'},
  {title:'Only Us',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',duration:'5:21'}]},
 {id:'blue-days',name:'Blue Days',mood:'SAD',desc:'Let the feelings have their moment.',color:'blue',icon:'☁',songs:[
  {title:'Falling Quiet',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',duration:'5:00'},
  {title:'Somewhere Else',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',duration:'5:10'},
  {title:'Empty Streets',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',duration:'5:20'}]},
 {id:'good-energy',name:'Good Energy',mood:'HAPPY',desc:'Bright sounds for brighter days.',color:'amber',icon:'✦',songs:[
  {title:'Sunshine State',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',duration:'5:04'},
  {title:'Weekend Again',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3',duration:'5:22'},
  {title:'Little Wins',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3',duration:'5:30'}]},
 {id:'focus',name:'Deep Focus',mood:'FOCUS',desc:'Find your flow. Leave the noise behind.',color:'mint',icon:'◉',songs:[
  {title:'Soft Focus',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3',duration:'5:10'},
  {title:'Still Mind',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3',duration:'5:18'},
  {title:'In the Zone',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3',duration:'5:08'}]},
 {id:'slow-down',name:'Slow Down',mood:'CHILL',desc:'Take a breath. You have time.',color:'violet',icon:'✧',songs:[
  {title:'Easy Does It',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3',duration:'5:15'},
  {title:'Breathe Out',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-17.mp3',duration:'5:12'},
  {title:'Quiet Place',artist:'MOODS Radio',url:'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-18.mp3',duration:'5:16'}]}
];
const defaultSongs = playlists.flatMap(p=>p.songs.map((s,i)=>({...s,playlistId:p.id,playlistName:p.name,index:i})));
const moodColors=['plum','rose','blue','amber','mint','violet'];
function resolvePlaylistLink(value){
 try{
  const url=new URL(value.trim());const host=url.hostname.toLowerCase().replace(/^www\./,'');
  if(host==='open.spotify.com'){
   const match=url.pathname.match(/^\/playlist\/([A-Za-z0-9]+)\/?$/);if(!match)return null;
   return {provider:'Spotify',sourceUrl:url.href,embedUrl:`https://open.spotify.com/embed/playlist/${match[1]}?utm_source=generator`};
  }
  if(['youtube.com','music.youtube.com','m.youtube.com'].includes(host)){
   const list=url.searchParams.get('list');if(!list)return null;
   return {provider:host==='music.youtube.com'?'YouTube Music':'YouTube',playlistId:list,sourceUrl:url.href,embedUrl:`https://www.youtube.com/embed?listType=playlist&list=${encodeURIComponent(list)}&playsinline=1`};
  }
  if(host==='jiosaavn.com'||host.endsWith('.jiosaavn.com'))return {provider:'JioSaavn',sourceUrl:url.href,embedUrl:''};
 }catch{}
 return null;
}
async function fetchYouTubePlaylist(playlistId){
 if(!youtubeApiKey)throw new Error('Add a YouTube Data API key as VITE_YOUTUBE_API_KEY in .env, then restart Vite.');
 const tracks=[];let pageToken='';
 do{
  const params=new URLSearchParams({part:'snippet',playlistId,maxResults:'50',key:youtubeApiKey});if(pageToken)params.set('pageToken',pageToken);
  const response=await fetch(`https://www.googleapis.com/youtube/v3/playlistItems?${params}`);const data=await response.json();
  if(!response.ok)throw new Error(data.error?.message||'Could not load this YouTube playlist.');
  for(const item of data.items||[]){const videoId=item.snippet?.resourceId?.videoId;if(videoId)tracks.push({title:item.snippet.title,artist:item.snippet.videoOwnerChannelTitle||item.snippet.channelTitle||'YouTube',youtubeVideoId:videoId,thumbnail:item.snippet.thumbnails?.medium?.url||item.snippet.thumbnails?.default?.url||''})}
  pageToken=data.nextPageToken||'';
 }while(pageToken&&tracks.length<500);
 if(!tracks.length)throw new Error('This playlist has no public playable videos.');
 return tracks;
}
function App(){
 const [activePlaylist,setActivePlaylist]=useState(playlists[0]); const [current,setCurrent]=useState(defaultSongs[0]); const [playing,setPlaying]=useState(false); const [query,setQuery]=useState(''); const [volume,setVolume]=useState(.75); const [progress,setProgress]=useState(0); const [duration,setDuration]=useState(0); const [shuffle,setShuffle]=useState(false); const [repeat,setRepeat]=useState(false); const [liked,setLiked]=useState([]); const [view,setView]=useState('home'); const [mobileNav,setMobileNav]=useState(false); const [loginOpen,setLoginOpen]=useState(false); const [roomOpen,setRoomOpen]=useState(false); const [adminOpen,setAdminOpen]=useState(false); const [account,setAccount]=useState(null); const [roomId,setRoomId]=useState(''); const [roomCode,setRoomCode]=useState(''); const [roomError,setRoomError]=useState(''); const [roomData,setRoomData]=useState(null); const [loginError,setLoginError]=useState(''); const [adminError,setAdminError]=useState(''); const [managedMoods,setManagedMoods]=useState(null);
 const visiblePlaylists=managedMoods??playlists;const allSongs=visiblePlaylists.flatMap(p=>(p.songs||[]).filter(s=>s.url).map((s,i)=>({...s,playlistId:p.id,playlistName:p.name,index:i})));
 const audio=useRef(null);const youtubePlayer=useRef(null);const nextSongRef=useRef(()=>{});
 useEffect(()=>{if(!auth)return;return onAuthStateChanged(auth,setAccount)},[]);
 useEffect(()=>{if(!database)return;return onValue(ref(database,'moods'),snapshot=>{const data=snapshot.val();if(data?.initialized){setManagedMoods(Object.values(data.items||{}).sort((a,b)=>(a.order||0)-(b.order||0)))}else setManagedMoods(null)})},[]);
 useEffect(()=>{if(visiblePlaylists.some(p=>p.id===activePlaylist.id))return;setActivePlaylist(visiblePlaylists[0]||playlists[0])},[visiblePlaylists,activePlaylist.id]);
 useEffect(()=>{
  if(!loginOpen||account||!auth||!googleClientId)return;
  const renderGoogleButton=()=>{
   const host=document.getElementById('google-signin-button');
   if(!host||!window.google?.accounts?.id)return;
   window.google.accounts.id.initialize({client_id:googleClientId,use_fedcm_for_button:true,callback:async response=>{
    try{setLoginError('');await signInWithCredential(auth,GoogleAuthProvider.credential(response.credential));setLoginOpen(false)}catch(error){setLoginError(error.message)}
   }});
   host.replaceChildren();
   window.google.accounts.id.renderButton(host,{theme:'filled_black',size:'large',shape:'pill',text:'continue_with',logo_alignment:'left',width:280});
  };
  if(window.google?.accounts?.id){renderGoogleButton();return}
  let script=document.querySelector('script[data-google-identity]');
  if(!script){script=document.createElement('script');script.src='https://accounts.google.com/gsi/client';script.async=true;script.defer=true;script.dataset.googleIdentity='true';script.onerror=()=>setLoginError('Google sign-in could not load. Check your internet connection.');document.head.appendChild(script)}
  script.addEventListener('load',renderGoogleButton);
  return()=>script.removeEventListener('load',renderGoogleButton);
 },[loginOpen,account]);
 useEffect(()=>{audio.current=new Audio();audio.current.volume=volume; const a=audio.current; const time=()=>setProgress(a.currentTime||0);const meta=()=>setDuration(a.duration||0);const ended=()=>nextSongRef.current();a.addEventListener('timeupdate',time);a.addEventListener('loadedmetadata',meta);a.addEventListener('ended',ended);return()=>{a.pause();a.removeEventListener('timeupdate',time);a.removeEventListener('loadedmetadata',meta);a.removeEventListener('ended',ended)}},[]);
 useEffect(()=>{if(!audio.current)return; audio.current.volume=volume},[volume]);
 const publishRoomPlayer=(song=current,isPlaying=playing,position=audio.current?.currentTime||0,extra={})=>{if(!database||!roomId||!account)return;update(ref(database,`rooms/${roomId}/player`),{songPlaylistId:song?.playlistId||activePlaylist.id,songIndex:song?.index??0,isPlaying,position,shuffle,repeat,volume,...extra,updatedAt:serverTimestamp()}).catch(error=>setRoomError(error.message))};
 useEffect(()=>{if(!database||!roomId||!account){setRoomData(null);return}const stop=onValue(ref(database,`rooms/${roomId}`),snapshot=>{const data=snapshot.val();if(!data){setRoomError('Room code not found.');setRoomData(null);return}setRoomError('');setRoomData(data);const state=data.player;if(!state)return;const song=allSongs.find(item=>item.playlistId===state.songPlaylistId&&item.index===state.songIndex);if(!song)return;setCurrent(song);const playlist=visiblePlaylists.find(item=>item.id===song.playlistId);if(playlist)setActivePlaylist(playlist);setShuffle(Boolean(state.shuffle));setRepeat(Boolean(state.repeat));setPlaying(Boolean(state.isPlaying));if(Number.isFinite(state.volume))setVolume(state.volume);const audioEl=audio.current;if(!audioEl)return;const expected=(Number(state.position)||0)+(state.isPlaying&&Number.isFinite(state.updatedAt)?Math.max(0,(Date.now()-state.updatedAt)/1000):0);const sameTrack=audioEl.src===song.url||audioEl.currentSrc===song.url;if(!sameTrack){audioEl.src=song.url;audioEl.load();audioEl.addEventListener('loadedmetadata',()=>{audioEl.currentTime=expected;if(state.isPlaying)audioEl.play().catch(()=>setPlaying(false))},{once:true})}else{if(Number.isFinite(audioEl.duration)&&Math.abs(audioEl.currentTime-expected)>1.5)audioEl.currentTime=expected;if(state.isPlaying&&audioEl.paused)audioEl.play().catch(()=>setPlaying(false));if(!state.isPlaying&&!audioEl.paused)audioEl.pause()}},error=>setRoomError(error.message));return stop},[roomId,account,visiblePlaylists]);
  const createRoom=async()=>{if(!account)return;if(activePlaylist.externalUrl){setRoomError('Leave the YouTube/Spotify playlist before creating a synced room.');return}if(!database){setRoomError('Set VITE_FIREBASE_DATABASE_URL in .env first.');return}try{setRoomError('');const newRoom=push(ref(database,'rooms'));const song=current||allSongs[0];await set(newRoom,{createdBy:account.uid,members:{[account.uid]:true},createdAt:serverTimestamp(),player:{songPlaylistId:song.playlistId,songIndex:song.index,isPlaying:playing,position:audio.current?.currentTime||0,shuffle,repeat,volume,updatedAt:serverTimestamp()}});setRoomId(newRoom.key);setRoomCode(newRoom.key)}catch(error){setRoomError(error.message)}};
  const joinRoom=async()=>{if(!database){setRoomError('Set VITE_FIREBASE_DATABASE_URL in .env first.');return}const code=roomCode.trim();if(!code){setRoomError('Enter a room code.');return}try{setRoomError('');await set(ref(database,`rooms/${code}/members/${account.uid}`),true);setRoomId(code)}catch(error){setRoomError(error.message)}};
 const playSong=(song,playlist)=>{if(!song?.url&&!song?.youtubeVideoId)return;setCurrent(song);if(playlist)setActivePlaylist(playlist);setPlaying(true);if(song.youtubeVideoId){audio.current?.pause();if(youtubePlayer.current){youtubePlayer.current.__moodsVideoId=song.youtubeVideoId;youtubePlayer.current.loadVideoById(song.youtubeVideoId)}return}if(audio.current){audio.current.src=song.url;audio.current.load();audio.current.play().catch(()=>setPlaying(false));}publishRoomPlayer(song,true,0)};
 const currentQueue=useMemo(()=> (activePlaylist.songs||[]).map((s,i)=>({...s,playlistId:activePlaylist.id,playlistName:activePlaylist.name,index:i})),[activePlaylist]);
  const nextSong=()=>{if(repeat&&current?.youtubeVideoId&&youtubePlayer.current){youtubePlayer.current.seekTo(0,true);youtubePlayer.current.playVideo();setPlaying(true);return}if(repeat&&audio.current){audio.current.currentTime=0;audio.current.play().catch(()=>setPlaying(false));setPlaying(true);publishRoomPlayer(current,true,0);return}const q=currentQueue;if(!q.length)return;let idx=q.findIndex(s=>s.title===current?.title);if(shuffle)idx=Math.floor(Math.random()*q.length);else idx=(idx+1)%q.length;playSong(q[idx]||defaultSongs[0],activePlaylist);};
 nextSongRef.current=nextSong;
 const prevSong=()=>{const time=current?.youtubeVideoId?youtubePlayer.current?.getCurrentTime?.()||0:audio.current?.currentTime||0;if(time>3){if(current?.youtubeVideoId)youtubePlayer.current?.seekTo(0,true);else audio.current.currentTime=0;publishRoomPlayer(current,true,0);return}const q=currentQueue;if(!q.length)return;let idx=q.findIndex(s=>s.title===current?.title);idx=(idx-1+q.length)%q.length;playSong(q[idx]||defaultSongs[0],activePlaylist);};
 const toggle=()=>{if(current?.youtubeVideoId){if(playing){youtubePlayer.current?.pauseVideo();setPlaying(false)}else{youtubePlayer.current?.playVideo();setPlaying(true)}return}if(!audio.current)return;if(playing){audio.current.pause();setPlaying(false);publishRoomPlayer(current,false,audio.current.currentTime||0)}else{audio.current.play().then(()=>{setPlaying(true);publishRoomPlayer(current,true,audio.current.currentTime||0)}).catch(()=>setPlaying(false))}};
 const seekTo=position=>{if(current?.youtubeVideoId)youtubePlayer.current?.seekTo(position,true);else if(audio.current)audio.current.currentTime=position;publishRoomPlayer(current,playing,position)};
 const toggleShuffle=next=>{setShuffle(next);publishRoomPlayer(current,playing,audio.current?.currentTime||0,{shuffle:next})};
 const toggleRepeat=next=>{setRepeat(next);publishRoomPlayer(current,playing,audio.current?.currentTime||0,{repeat:next})};
 const updateVolume=next=>{setVolume(next);if(audio.current)audio.current.volume=next;if(current?.youtubeVideoId)youtubePlayer.current?.setVolume(next*100);publishRoomPlayer(current,playing,audio.current?.currentTime||0,{volume:next})};
 const logout=async()=>{if(auth)await signOut(auth);setRoomId('');setLoginOpen(false);setAdminOpen(false)};
 const selectPlaylist=(p)=>{if(!p)return;if(p.externalUrl&&roomId){setRoomError('Leave this listening room before opening an external playlist.');setRoomOpen(true);return}setActivePlaylist(p);setView('playlist');setMobileNav(false);if(p.externalUrl){audio.current?.pause();setPlaying(false);if((p.provider==='YouTube'||p.provider==='YouTube Music')&&p.songs?.[0])setCurrent({...p.songs[0],playlistId:p.id,playlistName:p.name,index:0});return}const first=(p.songs||[])[0];if(first)playSong({...first,playlistId:p.id,playlistName:p.name,index:0},p)};
 const saveManagedMoods=async next=>{if(account?.email?.toLowerCase()!=='modpapai@gmail.com'){setAdminError('Admin access required.');return false}if(!database){setAdminError('Realtime Database is not configured.');return false}try{setAdminError('');const items=Object.fromEntries(next.map((mood,order)=>[mood.id,{...mood,order}]));await set(ref(database,'moods'),{initialized:true,items});setManagedMoods(next);return true}catch(error){setAdminError(error.code==='PERMISSION_DENIED'?'Firebase blocked this change. Publish database.rules.json in Firebase Console → Realtime Database → Rules, and confirm you are signed in as modpapai@gmail.com.':error.message);return false}};
 const searchResults=allSongs.filter(s=>(s.title+' '+s.artist+' '+s.playlistName).toLowerCase().includes(query.toLowerCase()));
 const fmt=t=>{if(!Number.isFinite(t))return '0:00';return `${Math.floor(t/60)}:${String(Math.floor(t%60)).padStart(2,'0')}`};
 return <div className="app-shell">
  <aside className={`sidebar ${mobileNav?'show':''}`}><div className="brand"><span className="brand-mark">M</span><span>MOODS<span className="brand-dot">.</span></span><button className="close-nav" onClick={()=>setMobileNav(false)}><X/></button></div>
   <div className="nav-group"><button className={`nav-link ${view==='home'?'active':''}`} onClick={()=>{setView('home');setMobileNav(false)}}><Home size={18}/>Home</button><button className={`nav-link ${view==='search'?'active':''}`} onClick={()=>{setView('search');setMobileNav(false)}}><Search size={18}/>Search</button><button className={`nav-link ${view==='library'?'active':''}`} onClick={()=>{setView('library');setMobileNav(false)}}><Library size={18}/>Your Library</button></div>
   <div className="side-heading">YOUR MOODS <span>+</span></div><div className="side-playlists">{visiblePlaylists.map(p=><button key={p.id} className={`side-play ${activePlaylist.id===p.id?'selected':''}`} onClick={()=>selectPlaylist(p)}><span className={`mini-cover ${p.color}`}>{p.icon}</span><span>{p.name}</span></button>)}</div>
   <div className="sidebar-bottom"><div className="side-note"><Headphones size={17}/><div><b>Find your frequency.</b><small>One mood at a time.</small></div></div><span className="side-version">MOODS WEB PLAYER · 1.0</span></div>
  </aside>
  {mobileNav&&<div className="nav-backdrop" onClick={()=>setMobileNav(false)}/>}
  <main className="main-area"><header className="topbar"><button className="menu-btn" onClick={()=>setMobileNav(true)}><Menu/></button><div className="history-btns"><button aria-label="Back">‹</button><button aria-label="Forward">›</button></div><div className="top-search"><Search size={17}/><input placeholder="What do you want to feel?" value={query} onChange={e=>{setQuery(e.target.value);if(e.target.value)setView('search')}} onFocus={()=>{}}/><kbd>⌘ K</kbd></div><div className="top-actions"><span className="online-pill"><i/> LISTENING SPACE</span><button className="room-open" onClick={()=>account?setRoomOpen(true):setLoginOpen(true)} title="Listen together"><UsersRound size={15}/><span>Listen together</span></button><button className="avatar" onClick={()=>setLoginOpen(true)} aria-label={account?`Account: ${account.email}`:'Sign in'}>{account?.photoURL?<img src={account.photoURL} alt=""/>:account?.displayName?.[0]?.toUpperCase()||<UserRound size={17}/>}</button></div></header>
  <div className="content-scroll">
   {view==='home'&&<><section className="hero"><div className="hero-text"><div className="eyebrow"><span className="eyebrow-line"/> YOUR SOUNDTRACK STARTS HERE</div><h1>How are you<br/><em>feeling</em> today?</h1><p>Every mood has a melody. Find yours.</p><button className="hero-cta" onClick={()=>selectPlaylist(visiblePlaylists[0])}><Play size={16} fill="currentColor"/> Explore your moods</button></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="hero-disc"><div className="disc-label">M<span>✦</span></div></div><div className="hero-spark spark-a">✦</div><div className="hero-spark spark-b">✧</div><div className="hero-glow"/></div><div className="hero-bottom"><span>CURATED FOR YOUR FEELING</span><span>SCROLL TO EXPLORE ↓</span></div></section>
    <section className="section"><div className="section-heading"><div><div className="eyebrow">PICK YOUR FEELING</div><h2>Made for <em>your moods</em></h2></div><button className="text-button" onClick={()=>setView('library')}>View all <span>↗</span></button></div><div className="mood-grid">{visiblePlaylists.map((p,i)=><button className={`mood-card ${p.color}`} key={p.id} onClick={()=>selectPlaylist(p)}><div className="card-top"><span className="mood-tag">{p.mood}</span>{p.provider&&p.provider!=='Spotify'&&<span className="provider-pill">{p.provider}</span>}<span className="card-arrow">↗</span></div><div className="cover-art"><div className="cover-shape shape1"/><div className="cover-shape shape2"/><div className="cover-symbol">{p.icon}</div><div className="cover-ring"/></div><div className="card-bottom"><div><h3>{p.name}</h3><p>{p.desc}</p></div></div><span className="round-play"><Play fill="currentColor" size={16}/></span></button>)}</div></section>
    <section className="section tracks-section"><div className="section-heading"><div><div className="eyebrow">A LITTLE SOMETHING FOR NOW</div><h2>On your <em>rotation</em></h2></div><button className="text-button" onClick={()=>setView('library')}>See playlist <span>↗</span></button></div><SongList songs={allSongs.slice(0,5)} current={current} playing={playing} onPlay={s=>playSong(s,visiblePlaylists.find(p=>p.id===s.playlistId))} liked={liked} toggleLike={s=>setLiked(a=>a.includes(s.title)?a.filter(x=>x!==s.title):[...a,s.title])}/></section>
   </>}
   {view==='playlist'&&<PlaylistView playlist={activePlaylist} playing={playing} currentQueue={currentQueue} current={current} liked={liked} onToggle={toggle} onPlay={s=>playSong(s,activePlaylist)} onLike={s=>setLiked(a=>a.includes(s.title)?a.filter(x=>x!==s.title):[...a,s.title])} onPlaylistLike={()=>setLiked(a=>a.includes(activePlaylist.name)?a.filter(x=>x!==activePlaylist.name):[...a,activePlaylist.name])} youtubePlayer={youtubePlayer} youtubeVolume={volume} onYoutubeState={setPlaying} onYoutubeProgress={(time,total)=>{setProgress(time);setDuration(total)}} onYoutubeEnded={()=>nextSongRef.current()}/>} 
   {view==='search'&&<section className="section search-view"><div className="eyebrow">SEARCH MOODS</div><h2>Find your <em>next sound.</em></h2><div className="search-large"><Search/><input autoFocus placeholder="Search songs or playlists..." value={query} onChange={e=>setQuery(e.target.value)}/></div><SongList songs={searchResults} current={current} playing={playing} onPlay={s=>playSong(s,visiblePlaylists.find(p=>p.id===s.playlistId))} liked={liked} toggleLike={s=>setLiked(a=>a.includes(s.title)?a.filter(x=>x!==s.title):[...a,s.title])}/></section>}
   {view==='library'&&<section className="section library-view"><div className="eyebrow">YOUR LIBRARY</div><h2>All your <em>moods.</em></h2><div className="mood-grid">{visiblePlaylists.map(p=><button className={`mood-card ${p.color}`} key={p.id} onClick={()=>selectPlaylist(p)}><div className="card-top"><span className="mood-tag">{p.mood}</span>{p.provider&&p.provider!=='Spotify'&&<span className="provider-pill">{p.provider}</span>}<span className="card-arrow">↗</span></div><div className="cover-art"><div className="cover-shape shape1"/><div className="cover-shape shape2"/><div className="cover-symbol">{p.icon}</div><div className="cover-ring"/></div><div className="card-bottom"><div><h3>{p.name}</h3><p>{p.desc}</p></div></div><span className="round-play"><Play fill="currentColor" size={16}/></span></button>)}</div></section>}
   <footer className="footer"><span>MOODS<span className="brand-dot">.</span></span><span>Music for every mood. Made with feeling.</span><span>© 2026 MOODS</span></footer>
  </div>
</main>

{(!activePlaylist.externalUrl||(view==='playlist'&&(activePlaylist.provider==='YouTube'||activePlaylist.provider==='YouTube Music')))&&<Player
  current={current}
  playing={playing}
  toggle={toggle}
  next={nextSong}
  prev={prevSong}
  progress={progress}
  duration={duration}
  seek={seekTo}
  volume={volume}
  setVolume={updateVolume}
  shuffle={shuffle}
  setShuffle={toggleShuffle}
  repeat={repeat}
  setRepeat={toggleRepeat}
  liked={liked.includes(current?.title)}
  toggleLike={() => {
    if (!current) return;
    setLiked(a =>
      a.includes(current.title)
        ? a.filter(x => x !== current.title)
        : [...a, current.title]
    );
  }}
/>}
 <LoginDialog open={loginOpen} onClose={()=>setLoginOpen(false)} account={account} onSignOut={logout} onAdmin={()=>{setLoginOpen(false);setAdminError('');setAdminOpen(true)}} configured={firebaseConfigured} clientId={googleClientId} error={loginError}/>
  <RoomDialog open={roomOpen} onClose={()=>setRoomOpen(false)} account={account} roomId={roomId} roomCode={roomCode} setRoomCode={setRoomCode} roomData={roomData} error={roomError} databaseReady={databaseConfigured} onCreate={createRoom} onJoin={joinRoom} onLeave={async()=>{try{if(database&&roomId&&account)await remove(ref(database,`rooms/${roomId}/members/${account.uid}`))}finally{setRoomId('');setRoomData(null)}}}/>
  <AdminDialog open={adminOpen} onClose={()=>setAdminOpen(false)} playlists={visiblePlaylists} onSave={saveManagedMoods} error={adminError} databaseReady={databaseConfigured}/>
</div>
}
function PlaylistView({playlist,playing,currentQueue,current,liked,onToggle,onPlay,onLike,onPlaylistLike,youtubePlayer,youtubeVolume,onYoutubeState,onYoutubeProgress,onYoutubeEnded}){
 const isYoutube=playlist.provider==='YouTube'||playlist.provider==='YouTube Music';
 return <section className={"playlist-view "+(isYoutube?'youtube-playlist-view':'')}><div className={"playlist-hero "+playlist.color}><div className="playlist-cover"><div className="cover-ring"/><span>{playlist.icon}</span></div><div className="playlist-info"><div className="eyebrow">MOODS PLAYLIST</div><h1>{playlist.name}</h1><p>{playlist.desc}</p><div className="playlist-meta"><span>{playlist.provider==='Spotify'?'MOODS PLAYLIST':playlist.provider||'MOODS EDITION'}</span><span>-</span><span>{playlist.externalUrl?'EXTERNAL PLAYLIST':(playlist.songs||[]).length+' TRACKS'}</span><span>-</span><span>MADE FOR YOU</span></div></div></div>{isYoutube?<YouTubePlaylistView playlist={playlist} current={current} playing={playing} volume={youtubeVolume} onPlay={onPlay} playerRef={youtubePlayer} onState={onYoutubeState} onProgress={onYoutubeProgress} onEnded={onYoutubeEnded}/>:playlist.externalUrl?<ExternalPlaylist playlist={playlist}/>:<><div className="playlist-controls"><button className="big-play" onClick={()=>playing?onToggle():currentQueue[0]&&onPlay(currentQueue[0])} disabled={!currentQueue.length}>{playing?<Pause fill="currentColor"/>:<Play fill="currentColor"/>}</button><button className="outline-button" onClick={onPlaylistLike}><Heart size={19}/></button><button className="outline-button"><ChevronDown size={19}/></button><span className="track-label">TRACKLIST</span></div><SongList songs={currentQueue} current={current} playing={playing} onPlay={onPlay} liked={liked} toggleLike={onLike}/></>}</section>
}
function ensureYouTubeApi(){
 if(window.YT?.Player)return Promise.resolve(window.YT);
 return new Promise(resolve=>{
  window.__moodsYouTubeCallbacks=window.__moodsYouTubeCallbacks||[];window.__moodsYouTubeCallbacks.push(resolve);
  if(!document.querySelector('script[data-moods-youtube-api]')){
   const previous=window.onYouTubeIframeAPIReady;window.onYouTubeIframeAPIReady=()=>{if(typeof previous==='function')previous();(window.__moodsYouTubeCallbacks||[]).splice(0).forEach(callback=>callback(window.YT))};
   const script=document.createElement('script');script.src='https://www.youtube.com/iframe_api';script.async=true;script.dataset.moodsYoutubeApi='true';document.head.appendChild(script);
  }
 });
}
function YouTubePlaylistView({playlist,current,playing,volume,onPlay,playerRef,onState,onProgress,onEnded}){
 const host=useRef(null);const [ready,setReady]=useState(false);const endedRef=useRef(onEnded);const progressRef=useRef(onProgress);endedRef.current=onEnded;progressRef.current=onProgress;
 useEffect(()=>{let disposed=false;ensureYouTubeApi().then(YT=>{if(disposed||!host.current)return;const player=new YT.Player(host.current,{width:'720',height:'405',videoId:playlist.songs?.[0]?.youtubeVideoId,playerVars:{controls:0,rel:0,playsinline:1,enablejsapi:1,origin:window.location.origin},events:{onReady:event=>{if(disposed)return;playerRef.current=event.target;event.target.setVolume(Math.round(volume*100));event.target.__moodsVideoId='';setReady(true)},onStateChange:event=>{if(event.data===YT.PlayerState.PLAYING)onState(true);else if(event.data===YT.PlayerState.PAUSED)onState(false);else if(event.data===YT.PlayerState.ENDED){onState(false);endedRef.current?.()}},onError:()=>onState(false)}});playerRef.current=player});return()=>{disposed=true;onState(false);if(playerRef.current){try{playerRef.current.destroy()}catch{}playerRef.current=null}}},[playlist.id]);
 useEffect(()=>{if(ready)playerRef.current?.setVolume(Math.round(volume*100))},[ready,volume,playerRef]);
 useEffect(()=>{if(!ready||!current?.youtubeVideoId||!playerRef.current)return;const player=playerRef.current;if(player.__moodsVideoId!==current.youtubeVideoId){player.__moodsVideoId=current.youtubeVideoId;if(playing)player.loadVideoById(current.youtubeVideoId);else player.cueVideoById(current.youtubeVideoId)}else if(playing)player.playVideo();else player.pauseVideo()},[ready,current?.youtubeVideoId,playing,playerRef]);
 useEffect(()=>{if(!ready||!playerRef.current)return;const timer=setInterval(()=>{try{progressRef.current(playerRef.current.getCurrentTime()||0,playerRef.current.getDuration()||0)}catch{}},400);return()=>clearInterval(timer)},[ready,playerRef]);
 return <div className="youtube-playlist-content"><div className="youtube-player-stage"><div ref={host} className="youtube-player-frame"/></div><div className="youtube-song-list">{(playlist.songs||[]).map((song,index)=><button className={"youtube-song-row "+(current?.youtubeVideoId===song.youtubeVideoId?'current':'')} key={song.youtubeVideoId||index} onClick={()=>onPlay({...song,playlistId:playlist.id,playlistName:playlist.name,index},playlist)}><span className="youtube-song-number">{current?.youtubeVideoId===song.youtubeVideoId&&playing?<span className="equalizer"><i/><i/><i/></span>:String(index+1).padStart(2,'0')}</span><span className="youtube-song-copy"><b>{song.title}</b><small>{song.artist}</small></span><Play className="youtube-song-play" size={15}/></button>)}</div></div>
}
function ExternalPlaylist({playlist}){
 const isSpotify=playlist.provider==='Spotify';
 if(isSpotify)return <div className="external-playlist spotify-track-panel"><SpotifyTrackList songs={playlist.songs||[]}/></div>;
 return <div className="external-playlist"><div className="external-note"><span className={"provider-mark "+playlist.provider?.toLowerCase().replace(/\s/g,'-')}>{playlist.provider}</span><span>Playback controls are provided by {playlist.provider}; they may require your account and do not sync to listening rooms.</span><a href={playlist.externalUrl} target="_blank" rel="noreferrer" aria-label={"Open "+playlist.name+" on "+playlist.provider}><ExternalLink size={15}/></a></div>{playlist.embedUrl?<iframe className="provider-embed youtube-embed" src={playlist.embedUrl} title={playlist.name+" on "+playlist.provider} loading="lazy" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" allowFullScreen referrerPolicy="strict-origin-when-cross-origin"/>:<div className="saavn-open-card"><div className="saavn-mark">J</div><div><b>Open this playlist on JioSaavn</b><small>JioSaavn will play it on its website or app.</small></div><a href={playlist.externalUrl} target="_blank" rel="noreferrer">Open playlist <ExternalLink size={14}/></a></div>}</div>
}
function SpotifyTrackList({songs}){return <div className="mood-track-list">{songs.length?songs.map((song,index)=><div className="mood-track-row" key={song.title+index}><span>{String(index+1).padStart(2,'0')}</span><b>{song.title}</b></div>):<div className="mood-track-empty">Add song names in Admin to show them here.</div>}</div>}
function AdminDialog({open,onClose,playlists,onSave,error,databaseReady}){
 const [name,setName]=useState('');
 const [category,setCategory]=useState('CHILL');
 const [description,setDescription]=useState('');
 const [url,setUrl]=useState('');
 const [songsText,setSongsText]=useState('');
 const [color,setColor]=useState('violet');
 const [icon,setIcon]=useState(String.fromCharCode(0x2726));
 const [formError,setFormError]=useState('');
 const [saving,setSaving]=useState(false);
 if(!open)return null;
 const addMood=async event=>{
  event.preventDefault();setFormError('');
  const source=resolvePlaylistLink(url);
  const songTitles=songsText.split(/\r?\n/).map(title=>title.trim()).filter(Boolean);
  if(!name.trim()||!url.trim()){setFormError('Add a mood name and playlist link.');return}
  if(!source){setFormError('Use a Spotify, YouTube / YouTube Music, or JioSaavn playlist URL.');return}
  if(source.provider==='Spotify'&&!songTitles.length){setFormError('Paste the song names, one per line.');return}
  if(!databaseReady){setFormError('Set up Firebase Realtime Database first.');return}
  let songs=source.provider==='Spotify'?songTitles.map(title=>({title,artist:'',url:''})):[];
  if(source.provider==='YouTube'||source.provider==='YouTube Music'){
   setSaving(true);
   try{songs=await fetchYouTubePlaylist(source.playlistId)}catch(fetchError){setSaving(false);setFormError(fetchError.message);return}
   setSaving(false);
  }
  const id=globalThis.crypto?.randomUUID?.()||'mood-'+Date.now().toString(36);
  const mood={id,name:name.trim(),mood:category,desc:description.trim()||category.toLowerCase()+' sounds for your mood.',color,icon:icon.trim()||String.fromCharCode(0x2726),songs,provider:source.provider,externalUrl:source.sourceUrl,embedUrl:source.embedUrl};
  setSaving(true);const success=await onSave([...playlists,mood]);setSaving(false);
  if(success){setName('');setDescription('');setUrl('');setSongsText('')}
 };
 const removeMood=async id=>{if(!databaseReady)return;setSaving(true);await onSave(playlists.filter(item=>item.id!==id));setSaving(false)};
 const spotifyLink=resolvePlaylistLink(url)?.provider==='Spotify';
 return <div className="admin-backdrop" onMouseDown={event=>{if(event.target===event.currentTarget)onClose()}}><section className="admin-panel" role="dialog" aria-modal="true" aria-labelledby="admin-title"><header className="admin-header"><div><div className="eyebrow">MOODS ADMIN STUDIO</div><h2 id="admin-title">Manage <em>moods</em></h2><p>Add a mood with a playlist link, or remove one from the library.</p></div><button className="auth-close" onClick={onClose} aria-label="Close admin panel"><X size={19}/></button></header><form className="admin-form" onSubmit={addMood}><label>Mood name<input value={name} onChange={event=>setName(event.target.value)} placeholder="e.g. Rainy evening" maxLength={36}/></label><label>Category<select value={category} onChange={event=>setCategory(event.target.value)}><option>CHILL</option><option>HAPPY</option><option>LOVE</option><option>SAD</option><option>FOCUS</option><option>ALONE</option><option>ENERGY</option></select></label><label className="admin-wide">Playlist URL<input type="url" value={url} onChange={event=>setUrl(event.target.value)} placeholder="Spotify, YouTube Music, YouTube, or JioSaavn link"/></label>{spotifyLink&&<label className="admin-wide">Song names<textarea className="admin-songs-input" value={songsText} onChange={event=>setSongsText(event.target.value)} placeholder={'One song name per line\nExample song 1\nExample song 2'} rows={5}/></label>}<label className="admin-wide">Description<input value={description} onChange={event=>setDescription(event.target.value)} placeholder="A short line about this mood" maxLength={100}/></label><label>Cover color<select value={color} onChange={event=>setColor(event.target.value)}>{moodColors.map(value=><option key={value} value={value}>{value[0].toUpperCase()+value.slice(1)}</option>)}</select></label><label>Cover icon<input value={icon} onChange={event=>setIcon(event.target.value)} maxLength={4}/></label><div className="admin-wide admin-form-footer"><small>YouTube lists use your MOODS player. Paste Spotify song names; JioSaavn opens separately.</small><button className="admin-add" type="submit" disabled={saving||!databaseReady}><Plus size={16}/>Add mood</button></div>{formError&&<p className="auth-error admin-wide">{formError}</p>}{error&&<p className="auth-error admin-wide">{error}</p>}</form><div className="admin-list-heading"><span>YOUR MOODS</span><span>{playlists.length}</span></div><div className="admin-list">{playlists.length?playlists.map(item=><article className="admin-mood-row" key={item.id}><span className={"mini-cover "+item.color}>{item.icon}</span><div className="admin-mood-info"><b>{item.name}</b><small>{item.provider||'MOODS playlist'} - {item.mood}</small></div>{item.externalUrl&&<a className="admin-source-link" href={item.externalUrl} target="_blank" rel="noreferrer" aria-label="Open playlist link"><ExternalLink size={15}/></a>}<button className="admin-remove" onClick={()=>removeMood(item.id)} disabled={saving||!databaseReady} aria-label={'Remove '+item.name} title="Remove mood"><Trash2 size={16}/></button></article>):<div className="admin-empty">No moods yet. Add one above.</div>}</div>{!databaseReady&&<p className="auth-setup admin-db-note">Firebase Realtime Database is not ready. Check <code>VITE_FIREBASE_DATABASE_URL</code>.</p>}</section></div>
}
function LoginDialog({open,onClose,account,onSignOut,onAdmin,configured,clientId,error}){if(!open)return null;const isAdmin=account?.email?.toLowerCase()==='modpapai@gmail.com';return <div className="auth-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><section className="auth-card login-card" role="dialog" aria-modal="true" aria-labelledby="auth-title"><button className="auth-close" onClick={onClose} aria-label="Close"><X size={18}/></button><div className="auth-mark">M</div>{account?<><div className="eyebrow">YOUR MOODS ACCOUNT</div><h2 id="auth-title">Welcome, {account.displayName||'listener'}</h2><p className="auth-copy">{account.email}</p>{isAdmin?<button className="account-role admin admin-manage" onClick={onAdmin}>ADMIN <span>Manage moods</span></button>:<span className="account-role">NORMAL USER</span>}<button className="auth-secondary" onClick={onSignOut}>Sign out</button></>:<><div className="eyebrow">YOUR SOUNDTRACK, YOUR SPACE</div><h2 id="auth-title">Welcome to <em>MOODS</em></h2><p className="auth-copy">Sign in to keep your music and listening rooms close.</p>{configured?clientId?<div id="google-signin-button" className="google-signin-button"/>:<p className="auth-setup">Add your Google OAuth Web client ID as <code>VITE_GOOGLE_CLIENT_ID</code> in <code>.env</code>.</p>:<p className="auth-setup">Firebase is not configured. Check the values in <code>.env</code>.</p>}{error&&<p className="auth-error">{error}</p>}<p className="auth-footnote">Secure sign-in with Google and Firebase</p></>}</section></div>}
function RoomDialog({open,onClose,account,roomId,roomCode,setRoomCode,roomData,error,databaseReady,onCreate,onJoin,onLeave}){if(!open)return null;return <div className="auth-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><section className="auth-card room-card" role="dialog" aria-modal="true" aria-labelledby="room-title"><button className="auth-close" onClick={onClose} aria-label="Close"><X size={18}/></button><div className="auth-mark"><UsersRound size={23}/></div><div className="eyebrow">MOODS LISTENING ROOM</div><h2 id="room-title">Listen <em>together</em></h2><p className="auth-copy">Share a room code. Playback controls stay synced for everyone in the room.</p>{account&&!databaseReady&&<p className="auth-setup">Create a Realtime Database, then add its URL to <code>VITE_FIREBASE_DATABASE_URL</code> in <code>.env</code>.</p>}{roomId?<><div className="room-code"><span>{roomId}</span><button onClick={()=>navigator.clipboard?.writeText(roomId)} aria-label="Copy room code"><Copy size={16}/></button></div><p className="room-status">{roomData?.player?.isPlaying?'Playing together':'Room connected'} · {roomData?.player?.songPlaylistId||'MOODS'}</p><button className="auth-secondary" onClick={onLeave}>Leave room</button></>:<>{account?<><button className="firebase-google-button room-create" onClick={onCreate}>Create a room</button><div className="room-divider"><span>OR JOIN A ROOM</span></div><div className="room-join"><input value={roomCode} onChange={e=>setRoomCode(e.target.value)} placeholder="Paste room code"/><button onClick={onJoin}>Join</button></div></>:<button className="firebase-google-button" onClick={()=>{onClose();document.querySelector('.avatar')?.click()}}>Sign in to create or join a room</button>}</>}{error&&<p className="auth-error">{error}</p>}<p className="auth-footnote">Anyone with the room code and an account can join.</p></section></div>}
function SongList({songs,current,playing,onPlay,liked,toggleLike}){return <div className="song-list"><div className="song-head"><span>#</span><span>TITLE</span><span>MOOD</span><span><ListMusic size={15}/></span></div>{songs.length===0?<div className="empty">No songs found. Try another search.</div>:songs.map((s,i)=><div className={`song-row ${current?.title===s.title?'current':''}`} key={`${s.title}-${i}`} onDoubleClick={()=>onPlay(s)}><span className="song-number">{current?.title===s.title&&playing?<span className="equalizer"><i/><i/><i/></span>:String(i+1).padStart(2,'0')}</span><button className="song-main" onClick={()=>onPlay(s)}><span className={`song-thumb ${['plum','rose','blue','amber','mint','violet'][i%6]}`}><Music2 size={16}/></span><span><b>{s.title}</b><small>{s.artist}</small></span></button><span className="song-mood">{s.playlistName||'MOODS'}</span><button className={`song-like ${liked.includes(s.title)?'liked':''}`} onClick={()=>toggleLike(s)} aria-label="Like song"><Heart size={15} fill={liked.includes(s.title)?'currentColor':'none'}/></button></div>)}</div>}
function Player({current,playing,toggle,next,prev,progress,duration,seek,volume,setVolume,shuffle,setShuffle,repeat,setRepeat,liked,toggleLike}){
 return <div className="player">
  <div className="player-track">
   <div className={"player-art "+(current?.playlistId||'late-night')+(current?.thumbnail?' youtube-art':'')}>{current?.thumbnail?<img src={current.thumbnail} alt="" referrerPolicy="strict-origin-when-cross-origin"/>:<Music2 size={20}/>}</div>
   <div className="player-track-info"><div className="player-title"><b>{current?.title||'Choose a song'}</b><small>{current?.artist||'MOODS Radio'}</small></div><div className="progress-row"><span>{formatTime(progress)}</span><input aria-label="Seek" type="range" min="0" max={duration||100} value={Math.min(progress,duration||100)} onChange={event=>seek(Number(event.target.value))} style={{'--progress':(duration?progress/duration*100:0)+'%'}}/><span>{formatTime(duration)}</span></div></div>
   <button className={"song-like "+(liked?'liked':'')} onClick={toggleLike} aria-label={liked?'Unlike song':'Like song'}><Heart size={16} fill={liked?'currentColor':'none'}/></button>
  </div>
  <div className="player-center"><div className="player-buttons"><button className={shuffle?'active-control':''} onClick={()=>setShuffle(!shuffle)} title="Shuffle"><Shuffle size={16}/></button><button onClick={prev} title="Previous"><SkipBack size={19} fill="currentColor"/></button><button className="play-button" onClick={toggle} title={playing?'Pause':'Play'}>{playing?<Pause size={18} fill="currentColor"/>:<Play size={18} fill="currentColor"/>}</button><button onClick={next} title="Next"><SkipForward size={19} fill="currentColor"/></button><button className={repeat?'active-control':''} onClick={()=>setRepeat(!repeat)} title="Repeat"><Repeat size={16}/></button></div></div>
  <div className="player-volume"><Volume2 size={17}/><input aria-label="Volume" type="range" min="0" max="1" step=".01" value={volume} onChange={event=>setVolume(Number(event.target.value))} style={{'--progress':(volume*100)+'%'}}/><button title="Queue" aria-label="Queue"><ListMusic size={17}/></button></div>
 </div>
}
function formatTime(t){if(!Number.isFinite(t))return '0:00';return `${Math.floor(t/60)}:${String(Math.floor(t%60)).padStart(2,'0')}`}

createRoot(document.getElementById('root')).render(<App/>);
